
let eliminated=JSON.parse(localStorage.getItem('eliminated')||'[]');

fetch('teams.json').then(r=>r.json()).then(data=>{
 const players=document.getElementById('players');
 const summary=document.getElementById('summary');

 function render(){
  players.innerHTML='';
  let aliveTotal=0;

  Object.entries(data).forEach(([name,teams])=>{
   const alive=teams.filter(t=>!eliminated.includes(t));
   aliveTotal+=alive.length;

   const card=document.createElement('div');
   card.className='card';
   card.innerHTML=`<h3>${name}</h3>
   <p>Equipos vivos: ${alive.length}/4</p>
   ${teams.map(t=>`<div class="team ${eliminated.includes(t)?'out':'alive'}">${t}</div>`).join('')}`;
   players.appendChild(card);
  });

  summary.innerHTML=`Participantes: 12 | Equipos vivos: ${aliveTotal}`;
 }

 document.getElementById('adminBtn').onclick=()=>{
   const team=prompt('Escribe exactamente el equipo eliminado:');
   if(team){
      if(!eliminated.includes(team)){
         eliminated.push(team);
         localStorage.setItem('eliminated',JSON.stringify(eliminated));
         render();
      }
   }
 };

 document.getElementById('resetBtn').onclick=()=>{
   if(confirm('¿Reiniciar eliminados?')){
      eliminated=[];
      localStorage.removeItem('eliminated');
      render();
   }
 };

 render();
});
